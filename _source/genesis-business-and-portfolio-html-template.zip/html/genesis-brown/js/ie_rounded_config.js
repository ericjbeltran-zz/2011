// JavaScript Document

/* IE only */
DD_roundies.addRule('#menu li ul', '6px');
DD_roundies.addRule('#pagenavi a', '4px');
DD_roundies.addRule('.button', '4px');
DD_roundies.addRule('.button2', '6px');
DD_roundies.addRule('.rollover', '10px');
DD_roundies.addRule('#filter', '10px');


